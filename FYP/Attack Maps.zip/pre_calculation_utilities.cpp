#include "pre_calculation_utilities.h"
void init_precalculation_utilities() {
	init_pawn_attacks();
	init_knight_attacks();
	init_king_attacks();
	init_rook_attack_mask();
	init_bishop_attack_mask();
	init_magic_numbers();
	init_slider_attacks(true);
	init_slider_attacks(false);
}
//|--------------------------------------------------------|
//|********************************************************|
//|				   General Utilities					   |
//|********************************************************|
//|--------------------------------------------------------|
uint64_t rook_attacks[64];
uint64_t rook_attacks_table[64][4096];
uint64_t bishop_attacks[64];
uint64_t bishop_attacks_table[64][512];
int count_set_bits(uint64_t bitboard) {
	int count = 0;
	while (bitboard) {
		bitboard &= bitboard - 1;
		count++;
	}
	return count;
}
int get_least_bit_index(uint64_t bitboard) {
	if (!bitboard)
		return -1;
	else
		return log2(bitboard & -(long long)bitboard);
}
uint64_t setOccupancy(int index, int attacksCount, uint64_t pieceAttacksMap) {
	uint64_t occupancy = 0ull;
	for (int i = 0; i < attacksCount; i++) {
		int bit_index = get_least_bit_index(pieceAttacksMap);
		pieceAttacksMap &= pieceAttacksMap - 1;
		if (index & (1 << i)) {
			occupancy |= (bitmask(bit_index));
		}
	}
	return occupancy;
}
void init_slider_attacks(bool bishop) {
	for (int i = a8; i <= h1; i++) {
		bishop_attacks[i] = get_bishop_attak_mask_exc_ends(bitmask(i));
		rook_attacks[i] = get_rook_attak_mask_exc_ends(bitmask(i));
		uint64_t attack_mask = bishop?bishop_attacks[i] : rook_attacks[i];
		int relevent_bits = count_set_bits(attack_mask);
		int occupancy_indices = (1 << relevent_bits);
		for (int index = 0; index < occupancy_indices; index++) {
			if (bishop) {
				uint64_t occupancy = setOccupancy(index, relevent_bits, attack_mask);
				int magic_index = (occupancy * bishop_magic_number[i]) >> (64-bishop_attack_count[i]);
				bishop_attacks_table[i][magic_index] = get_bishop_attak_mask_inc_end_blockers(bitmask(i), occupancy);
			}
			else {
				uint64_t occupancy = setOccupancy(index, relevent_bits, attack_mask);
				int magic_index = (occupancy * rook_magic_number[i]) >> (64 - rook_attack_count[i]);
				rook_attacks_table[i][magic_index] = get_rook_attak_mask_inc_end_blockers(bitmask(i), occupancy);
			}
		}
	}
}
//|--------------------------------------------------------|
//|********************************************************|
//|				       Random Numbers					   |
//|********************************************************|
//|--------------------------------------------------------|
unsigned int random_state = 1804289383;
uint32_t get_32b_rand_no() {
	unsigned int number = random_state;
	number ^= number << 13;
	number ^= number >> 17;
	number ^= number << 5;
	random_state = number;
	return random_state;
}
uint64_t get_64b_rand_no() {
	uint64_t n1 = ((uint64_t)get_32b_rand_no()) & 0xFFFF;
	uint64_t n2 = ((uint64_t)get_32b_rand_no()) & 0xFFFF;
	uint64_t n3 = ((uint64_t)get_32b_rand_no()) & 0xFFFF;
	uint64_t n4 = ((uint64_t)get_32b_rand_no()) & 0xFFFF;
	return n1 | (n2 << 16) | (n3 << 32) | (n4 << 48);
}
//|--------------------------------------------------------|
//|********************************************************|
//|				       Magic Numbers					   |
//|********************************************************|
//|--------------------------------------------------------|
uint64_t bishop_magic_number[64];
uint64_t rook_magic_number[64];
void init_magic_numbers() {
	for (int i = a8; i <= h1; i++)
		rook_magic_number[i] = find_magic_number(bitmask(i), rook_attack_count[i], false);
	for (int i = a8; i <= h1; i++)
		bishop_magic_number[i] = find_magic_number(bitmask(i), bishop_attack_count[i], true);
}
uint64_t generate_magic_number() {
	return get_64b_rand_no()& get_64b_rand_no()& get_64b_rand_no();
}
uint64_t find_magic_number(uint64_t piece_position, int relevent_occupancy_bits, bool bishop) {
	uint64_t occupancies[4096];
	uint64_t attacks[4096];
	uint64_t used_attacks[4096];
	uint64_t attack_mask = bishop ? get_bishop_attak_mask_exc_ends(piece_position) : get_rook_attak_mask_exc_ends(piece_position);
	int occupancy_indicies = (1 << relevent_occupancy_bits);
	for (int index = 0; index < occupancy_indicies; index++) {
		occupancies[index] = setOccupancy(index, relevent_occupancy_bits, attack_mask);
		attacks[index] = bishop ? get_bishop_attak_mask_inc_end_blockers(piece_position, occupancies[index]) : get_rook_attak_mask_inc_end_blockers(piece_position, occupancies[index]);
	}
	for (int random_count = 0; random_count < 100000000; random_count++) {
		uint64_t magic_number = generate_magic_number();
		uint64_t num_to_multiply = 0xFF00000000000000;
		if (count_set_bits((attack_mask * magic_number) & num_to_multiply) < 6)continue;
		memset(used_attacks, 0ULL, sizeof(used_attacks));
		int index, fail;
		// test magic index loop
		for (index = 0, fail = 0; !fail && index < occupancy_indicies; index++) {
			int magic_index = (int)((occupancies[index] * magic_number) >> (64 - relevent_occupancy_bits));
			if (used_attacks[magic_index] == 0ull)
				used_attacks[magic_index] = attacks[index];
			else if (used_attacks[magic_index] != attacks[index])
				fail = true;
		}
		if (!fail)
			return magic_number;
	}
	return 0ull;
}
//|--------------------------------------------------------|
//|********************************************************|
//|							Pawns						   |
//|********************************************************|
//|--------------------------------------------------------|
uint64_t pawn_attack_maps[2][64];
void init_pawn_attacks() {
	for (int side = BLACK; side <= WHITE; side++)
		for (int position = a8; position <= h1; position++)
			pawn_attack_maps[side][position] = get_pawn_attack(side, position);
}
uint64_t get_pawn_attack(int side, int position) {
	uint64_t attacks = 0ull;
	uint64_t piece_position = bitmask(position);
	switch (side)
	{
	case BLACK:
		//south-west
		if ((piece_position << 7) & ~right_edge)
			attacks |= piece_position << 7;
		//south-east
		if ((piece_position << 9) & ~left_edge)
			attacks |= piece_position << 9;
		break;
	case WHITE:
		//north-west
		if ((piece_position >> 9) & ~right_edge)
			attacks |= piece_position >> 9;
		//north-east
		if ((piece_position >> 7) & ~left_edge)
			attacks |= piece_position >> 7;
		break;
	}
	return attacks;
}
//|--------------------------------------------------------|
//|********************************************************|
//|							Kings						   |
//|********************************************************|
//|--------------------------------------------------------|
uint64_t king_attack_maps[64];
void init_king_attacks() {
	for (int position = a8; position <= h1; position++)
		king_attack_maps[position] = get_king_attack(position);
}
uint64_t get_king_attack(int position) {
	uint64_t attacks = 0ull;
	uint64_t piece_position = bitmask(position);
	//south-west
	if ((piece_position << 7) & ~right_edge)
		attacks |= piece_position << 7;
	//south-east
	if ((piece_position << 9) & ~left_edge)
		attacks |= piece_position << 9;
	//north-west
	if ((piece_position >> 9) & ~right_edge)
		attacks |= piece_position >> 9;
	//north-east
	if ((piece_position >> 7) & ~left_edge)
		attacks |= piece_position >> 7;
	//west
	if (piece_position & ~left_edge)
		attacks |= piece_position >> 1;
	//east
	if (piece_position & ~right_edge)
		attacks |= piece_position << 1;
	//north
	attacks |= piece_position >> 8;
	attacks |= piece_position << 8;
	return attacks;
}
//|--------------------------------------------------------|
//|********************************************************|
//|							Knights						   |
//|********************************************************|
//|--------------------------------------------------------|
uint64_t knight_attack_maps[64];
void init_knight_attacks() {
	for (int position = a8; position <= h1; position++)
		knight_attack_maps[position] = get_knight_attack(position);
}
uint64_t get_knight_attack(int position) {
	uint64_t attacks = 0ull;
	uint64_t piece_position = bitmask(position);
	//south-west
	if ((piece_position << 6) & ~(right_edge | before_right_edge))
		attacks |= piece_position << 6;
	//south-east
	if ((piece_position << 10) & ~(left_edge | before_left_edge))
		attacks |= piece_position << 10;
	//north-west
	if ((piece_position >> 10) & ~(right_edge | before_right_edge))
		attacks |= piece_position >> 10;
	//north-east
	if ((piece_position >> 6) & ~(left_edge | before_left_edge))
		attacks |= piece_position >> 6;
	//south-west-south
	if ((piece_position << 15) & ~right_edge)
		attacks |= piece_position << 15;
	//south-east-south
	if ((piece_position << 17) & ~left_edge)
		attacks |= piece_position << 17;
	//north-west-north
	if ((piece_position >> 17) & ~right_edge)
		attacks |= piece_position >> 17;
	//north-east-north
	if ((piece_position >> 15) & ~left_edge)
		attacks |= piece_position >> 15;
	return attacks;
}
//|--------------------------------------------------------|
//|********************************************************|
//|							Rooks						   |
//|********************************************************|
//|--------------------------------------------------------|
int rook_attack_count[64];
void init_rook_attack_mask() {
	init_rook_attack_count();
}
void init_rook_attack_count() {
	for (int position = a8; position <= h1; position++)
		rook_attack_count[position] = count_set_bits(get_rook_attak_mask_exc_ends(bitmask(position)));
}
uint64_t get_rook_attak_mask_exc_ends(uint64_t piecePosition) {
	uint64_t attack_mask = 0ull;
	//******************Rook**********************
	int row = (log2(piecePosition) / 8);
	int col = ((int)(log2(piecePosition)) % 8);
	//north moves
	for (int rank = row + 1; rank <= 6; rank++)
		attack_mask |= (1ull << (rank * 8 + col));
	//south moves
	for (int rank = row - 1; rank >= 1; rank--)
		attack_mask |= (1ull << (rank * 8 + col));
	//east moves
	for (int file = col - 1; file >= 1; file--)
		attack_mask |= (1ull << (row * 8 + file));
	//west moves
	for (int file = col + 1; file <= 6; file++)
		attack_mask |= (1ull << (row * 8 + file));
	return attack_mask;
}
uint64_t get_rook_attak_mask_inc_end_blockers(uint64_t piecePosition, uint64_t blockers_board) {
	uint64_t attack_mask = 0ull;
	//******************Rook**********************
	int row = (log2(piecePosition) / 8);
	int col = ((int)(log2(piecePosition)) % 8);
	//north moves
	for (int rank = row + 1; rank <= 7; rank++) {
		attack_mask |= (1ull << (rank * 8 + col));
		if (blockers_board & (1ull << (rank * 8 + col)))
			break;
	}
	//south moves
	for (int rank = row - 1; rank >= 0; rank--) {
		attack_mask |= (1ull << (rank * 8 + col));
		if (blockers_board & (1ull << (rank * 8 + col)))
			break;
	}
	//east moves
	for (int file = col - 1; file >= 0; file--) {
		attack_mask |= (1ull << (row * 8 + file));
		if (blockers_board & (1ull << (row * 8 + file)))
			break;
	}
	//west moves
	for (int file = col + 1; file <= 7; file++) {
		attack_mask |= (1ull << (row * 8 + file));
		if (blockers_board & (1ull << (row * 8 + file)))
			break;
	}
	return attack_mask;
}
uint64_t get_rook_attacks(int position, uint64_t occupancy) {
	occupancy &= rook_attacks[position];
	occupancy *= rook_magic_number[position];
	occupancy >>= (64 - rook_attack_count[position]);
	return rook_attacks_table[position][occupancy];
}
//|--------------------------------------------------------|
//|********************************************************|
//|							Bishops						   |
//|********************************************************|
//|--------------------------------------------------------|
int bishop_attack_count[64];
void init_bishop_attack_mask() {
	init_bishop_attack_count();
}
void init_bishop_attack_count() {
	for (int position = a8; position <= h1; position++)
		bishop_attack_count[position] = count_set_bits(get_bishop_attak_mask_exc_ends(bitmask(position)));
}
uint64_t get_bishop_attak_mask_exc_ends(uint64_t piecePosition) {
	uint64_t attack_mask = 0ull;
	int row = (log2(piecePosition) / 8);
	int col = ((int)(log2(piecePosition)) % 8);
	//north-east moves
	for (int rank = row + 1, file = col - 1; rank <= 6 && file >= 1; rank++, file--)
		attack_mask |= (1ull << (rank * 8 + file));
	//north-west moves
	for (int rank = row + 1, file = col + 1; rank <= 6 && file <= 6; rank++, file++)
		attack_mask |= (1ull << (rank * 8 + file));
	//south-east moves
	for (int rank = row - 1, file = col - 1; rank >= 1 && file >= 1; rank--, file--)
		attack_mask |= (1ull << (rank * 8 + file));
	//south-west moves
	for (int rank = row - 1, file = col + 1; rank >= 1 && file <= 6; rank--, file++)
		attack_mask |= (1ull << (rank * 8 + file));
	return attack_mask;
}
uint64_t get_bishop_attak_mask_inc_end_blockers(uint64_t piecePosition, uint64_t blockers_board) {
	uint64_t attack_mask = 0ull;
	int row = (log2(piecePosition) / 8);
	int col = ((int)(log2(piecePosition)) % 8);
	//north-east moves
	for (int rank = row + 1, file = col - 1; rank <= 7 && file >= 0; rank++, file--) {
		attack_mask |= (1ull << (rank * 8 + file));
		if (blockers_board & (1ull << (rank * 8 + file)))
			break;
	}
	//north-west moves
	for (int rank = row + 1, file = col + 1; rank <= 7 && file <= 7; rank++, file++) {
		attack_mask |= (1ull << (rank * 8 + file));
		if (blockers_board & (1ull << (rank * 8 + file)))
			break;
	}
	//south-east moves
	for (int rank = row - 1, file = col - 1; rank >= 0 && file >= 0; rank--, file--) {
		attack_mask |= (1ull << (rank * 8 + file));
		if (blockers_board & (1ull << (rank * 8 + file)))
			break;
	}
	//south-west moves
	for (int rank = row - 1, file = col + 1; rank >= 0 && file <= 7; rank--, file++) {
		attack_mask |= (1ull << (rank * 8 + file));
		if (blockers_board & (1ull << (rank * 8 + file)))
			break;
	}
	return attack_mask;
}
uint64_t get_bishop_attacks(int position, uint64_t occupancy) {
	occupancy &= bishop_attacks[position];
	occupancy *= bishop_magic_number[position];
	occupancy >>= (64 - bishop_attack_count[position]);
	return bishop_attacks_table[position][occupancy];
}
