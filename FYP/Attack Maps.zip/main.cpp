#include "pre_calculation_utilities.h"
#include "game_pretty.h"
int main() {
	init_precalculation_utilities();
	uint64_t blocker = 0ull;
	blocker |= bitmask(a2);
	blocker |= bitmask(b2);
	blocker |= bitmask(b1);
	uint64_t piece_position = bitmask(a1);
	cout << "BLOCKERS BOARD : \n";
	printBitboard(blocker);
	cout << "Bishop attacks BOARD : \n";
	printBitboard(get_bishop_attacks(log2(piece_position),blocker));
	cout << "Rook attacks BOARD : \n";
	printBitboard(get_rook_attacks(log2(piece_position), blocker));
}