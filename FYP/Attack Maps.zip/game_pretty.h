#pragma once
#include<iostream>
#include<bitset>
using namespace std;
void print_bits(uint64_t, string end = "", string start = "");
string get_bits(uint64_t, string end = "", string start = "");
void printBitboard(uint64_t);
uint64_t getBitboard(int, int);